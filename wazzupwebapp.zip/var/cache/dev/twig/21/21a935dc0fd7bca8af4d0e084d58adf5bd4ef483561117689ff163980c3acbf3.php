<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* signup/thanks.html.twig */
class __TwigTemplate_96b54af8e8e82a3198633efe0058fb83ac78278e8f671c5e21c57549f87e075e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "signup/thanks.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "signup/thanks.html.twig"));

        // line 1
        $this->displayBlock('head', $context, $blocks);
        // line 6
        $this->displayBlock('body', $context, $blocks);
        // line 28
        echo "  ";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 1
    public function block_head($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head"));

        // line 2
        echo "<head>
<link rel='stylesheet' id='main-style-css'  href=\"";
        // line 3
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("thanks/css/style.css"), "html", null, true);
        echo "\" type='text/css' media='all' />
</head>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 6
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "<body style=\"background:linear-gradient(90deg, rgba(0,119,119,1) 64%, rgba(200,200,200,1) 100%);\">

<section class=\"main h-100\">
<div class=\"pv3 pv0-ns ph3 ph0-ns page-container\">
            <div id=\"form\" class=\"pv5 tc\">
                <div class=\"f4 mt4 tc subtitle\">
                    <h2 class=\"mb2 pb0\">Merci pour votre confiance ! 🖐 </h2>
                    <p class=\"pt0 mt0\">Votre compte à été créé avec succès</p>
                  </div>
                  <img class=\"mt4\" src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("thanks/img/sent.gif"), "html", null, true);
        echo "\" width=\"20%\">
                  <h3 class=\"mt4 mb3\">Veuillez vérifier votre boîte de réception<br>pour bien <span style=\"color:greenyellow;\">activer votre compte !</span></h3>
                <div class=\"success\">
                  <p class=\"text\">
                    Si vous ne le voyez pas, vérifiez le dossier SPAM<br>
                    Comme parfois notre e-mail d'activation reste bloqué ici
                  </p>
                </div>              
            </div>
</section>
</body>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "signup/thanks.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  106 => 16,  95 => 7,  85 => 6,  72 => 3,  69 => 2,  59 => 1,  49 => 28,  47 => 6,  45 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% block head %}
<head>
<link rel='stylesheet' id='main-style-css'  href=\"{{asset('thanks/css/style.css')}}\" type='text/css' media='all' />
</head>
{% endblock %}
{% block body %}
<body style=\"background:linear-gradient(90deg, rgba(0,119,119,1) 64%, rgba(200,200,200,1) 100%);\">

<section class=\"main h-100\">
<div class=\"pv3 pv0-ns ph3 ph0-ns page-container\">
            <div id=\"form\" class=\"pv5 tc\">
                <div class=\"f4 mt4 tc subtitle\">
                    <h2 class=\"mb2 pb0\">Merci pour votre confiance ! 🖐 </h2>
                    <p class=\"pt0 mt0\">Votre compte à été créé avec succès</p>
                  </div>
                  <img class=\"mt4\" src=\"{{asset('thanks/img/sent.gif')}}\" width=\"20%\">
                  <h3 class=\"mt4 mb3\">Veuillez vérifier votre boîte de réception<br>pour bien <span style=\"color:greenyellow;\">activer votre compte !</span></h3>
                <div class=\"success\">
                  <p class=\"text\">
                    Si vous ne le voyez pas, vérifiez le dossier SPAM<br>
                    Comme parfois notre e-mail d'activation reste bloqué ici
                  </p>
                </div>              
            </div>
</section>
</body>
{% endblock %}
  ", "signup/thanks.html.twig", "C:\\Users\\malek\\Desktop\\wazzupwebapp\\templates\\signup\\thanks.html.twig");
    }
}
