<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/sidebar.html.twig */
class __TwigTemplate_393cdc9308c4290f3426346e3a17e3c7fe97c28979d8acd3a24d03091ea544cd extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/sidebar.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/sidebar.html.twig"));

        // line 1
        echo "<!-- BEGIN: Main Menu-->
    <div class=\"main-menu menu-fixed menu-light menu-accordion menu-shadow\" data-scroll-to-active=\"true\">
        <div class=\"navbar-header\">
            <ul class=\"nav navbar-nav flex-row\">
                <li class=\"nav-item mr-auto\"><a class=\"navbar-brand\" href=\"";
        // line 5
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_home");
        echo "\"><img  src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("collab/wazzup.png"), "html", null, true);
        echo "\"style = \"margin-top:-15%\" alt=\"avatar\" height=\"120\" width=\"120\">
                        <h2 class=\"brand-text\" style = \"margin-left: -20%; margin-top:-20%\">Wazzup</h2>
                    </a></li>
                <li class=\"nav-item nav-toggle\"><a class=\"nav-link modern-nav-toggle pr-0\" data-toggle=\"collapse\"><i class=\"d-block d-xl-none text-primary toggle-icon font-medium-4\" data-feather=\"x\"></i><i class=\"d-none d-xl-block collapse-toggle-icon font-medium-4  text-primary\" data-feather=\"disc\" data-ticon=\"disc\"></i></a></li>
            </ul>
        </div>
        <br><br><br>
        <div class=\"shadow-bottom\"></div>
        <div class=\"main-menu-content\">
            <ul class=\"navigation navigation-main\" id=\"main-menu-navigation\" data-menu=\"menu-navigation\">
              <li class=\" nav-item\"><a class=\"d-flex align-items-center\" href=\"#\"><i data-feather=\"user\"></i><span class=\"menu-title text-truncate\" data-i18n=\"User\">Utilisateur</span></a>
                    <ul class=\"menu-content\">
                        <li><a class=\"d-flex align-items-center\" href=\"app-user-list.html\"><i data-feather=\"edit\"></i><span class=\"menu-item text-truncate\" data-i18n=\"List\">Profile</span></a>
                        </li>
                        <li><a class=\"d-flex align-items-center\" href=\"app-user-edit.html\"><i data-feather=\"layout\"></i><span class=\"menu-item text-truncate\" data-i18n=\"Edit\">Actualités</span></a>
                        </li>
                    </ul>
                </li>
                
                        <li><a class=\"d-flex align-items-center\" href=\"";
        // line 24
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_collab");
        echo "\"><i data-feather=\"users\"></i><span class=\"menu-item text-truncate\" data-i18n=\"Profile\">Collaboration</span></a>
                        </li>      
                        <li><a class=\"d-flex align-items-center\" href=\"page-account-settings.html\"><i data-feather=\"calendar\"></i><span class=\"menu-item text-truncate\" data-i18n=\"Account Settings\">Evenement</span></a>
                        </li>
                        
                        <li><a class=\"d-flex align-items-center\" href=\"page-faq.html\"><i data-feather=\"credit-card\"  > </i><span class=\"menu-item text-truncate\" data-i18n=\"FAQ\">Paiement</span></a>
                      
                        </li>
                        <br><br><br><br>
                        <br><br><br><br><br>
                        <br><br><br><br><br><br><br><br>
                        <li><a class=\"d-flex align-items-center\" href=\"page-knowledge-base.html\"><i data-feather=\"log-out\" style = \"margin-left: 40%; color:red\"></i><span class=\"menu-item text-truncate\" data-i18n=\"Knowledge Base\"></span></a>
                        </li>
                       
                      
                     
                        </li>
                    </ul>
                </li>
                
            </ul>
        </div>
    </div>
    <!-- END: Main Menu-->
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "home/sidebar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 24,  49 => 5,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!-- BEGIN: Main Menu-->
    <div class=\"main-menu menu-fixed menu-light menu-accordion menu-shadow\" data-scroll-to-active=\"true\">
        <div class=\"navbar-header\">
            <ul class=\"nav navbar-nav flex-row\">
                <li class=\"nav-item mr-auto\"><a class=\"navbar-brand\" href=\"{{ path('app_home') }}\"><img  src=\"{{ asset('collab/wazzup.png') }}\"style = \"margin-top:-15%\" alt=\"avatar\" height=\"120\" width=\"120\">
                        <h2 class=\"brand-text\" style = \"margin-left: -20%; margin-top:-20%\">Wazzup</h2>
                    </a></li>
                <li class=\"nav-item nav-toggle\"><a class=\"nav-link modern-nav-toggle pr-0\" data-toggle=\"collapse\"><i class=\"d-block d-xl-none text-primary toggle-icon font-medium-4\" data-feather=\"x\"></i><i class=\"d-none d-xl-block collapse-toggle-icon font-medium-4  text-primary\" data-feather=\"disc\" data-ticon=\"disc\"></i></a></li>
            </ul>
        </div>
        <br><br><br>
        <div class=\"shadow-bottom\"></div>
        <div class=\"main-menu-content\">
            <ul class=\"navigation navigation-main\" id=\"main-menu-navigation\" data-menu=\"menu-navigation\">
              <li class=\" nav-item\"><a class=\"d-flex align-items-center\" href=\"#\"><i data-feather=\"user\"></i><span class=\"menu-title text-truncate\" data-i18n=\"User\">Utilisateur</span></a>
                    <ul class=\"menu-content\">
                        <li><a class=\"d-flex align-items-center\" href=\"app-user-list.html\"><i data-feather=\"edit\"></i><span class=\"menu-item text-truncate\" data-i18n=\"List\">Profile</span></a>
                        </li>
                        <li><a class=\"d-flex align-items-center\" href=\"app-user-edit.html\"><i data-feather=\"layout\"></i><span class=\"menu-item text-truncate\" data-i18n=\"Edit\">Actualités</span></a>
                        </li>
                    </ul>
                </li>
                
                        <li><a class=\"d-flex align-items-center\" href=\"{{ path('app_collab') }}\"><i data-feather=\"users\"></i><span class=\"menu-item text-truncate\" data-i18n=\"Profile\">Collaboration</span></a>
                        </li>      
                        <li><a class=\"d-flex align-items-center\" href=\"page-account-settings.html\"><i data-feather=\"calendar\"></i><span class=\"menu-item text-truncate\" data-i18n=\"Account Settings\">Evenement</span></a>
                        </li>
                        
                        <li><a class=\"d-flex align-items-center\" href=\"page-faq.html\"><i data-feather=\"credit-card\"  > </i><span class=\"menu-item text-truncate\" data-i18n=\"FAQ\">Paiement</span></a>
                      
                        </li>
                        <br><br><br><br>
                        <br><br><br><br><br>
                        <br><br><br><br><br><br><br><br>
                        <li><a class=\"d-flex align-items-center\" href=\"page-knowledge-base.html\"><i data-feather=\"log-out\" style = \"margin-left: 40%; color:red\"></i><span class=\"menu-item text-truncate\" data-i18n=\"Knowledge Base\"></span></a>
                        </li>
                       
                      
                     
                        </li>
                    </ul>
                </li>
                
            </ul>
        </div>
    </div>
    <!-- END: Main Menu-->
", "home/sidebar.html.twig", "C:\\Users\\malek\\Desktop\\wazzupwebapp\\templates\\home\\sidebar.html.twig");
    }
}
