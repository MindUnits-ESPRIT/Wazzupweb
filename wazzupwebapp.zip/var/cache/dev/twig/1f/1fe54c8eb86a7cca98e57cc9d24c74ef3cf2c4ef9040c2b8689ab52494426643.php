<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @FlasherSymfony/bootstrap.html.twig */
class __TwigTemplate_7d1694fe85b8f5bb6f403c5566658fd079a6f9c5161e434d87665c515c94c675 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@FlasherSymfony/bootstrap.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@FlasherSymfony/bootstrap.html.twig"));

        // line 1
        if ((0 === twig_compare("success", twig_get_attribute($this->env, $this->source, (isset($context["envelope"]) || array_key_exists("envelope", $context) ? $context["envelope"] : (function () { throw new RuntimeError('Variable "envelope" does not exist.', 1, $this->source); })()), "type", [], "any", false, false, false, 1)))) {
            // line 2
            echo "    ";
            $context["title"] = "Success";
            // line 3
            echo "    ";
            $context["alert_class"] = "alert-success";
            // line 4
            echo "    ";
            $context["progress_bg_color"] = "#155724";
            // line 5
            echo "    ";
            $context["icon"] = "<svg class=\"bi flex-shrink-0 me-2\" width=\"24\" height=\"24\" role=\"img\" aria-label=\"Success:\"><use xlink:href=\"#check-circle-fill\"/></svg>";
        } elseif ((0 === twig_compare("error", twig_get_attribute($this->env, $this->source,         // line 6
(isset($context["envelope"]) || array_key_exists("envelope", $context) ? $context["envelope"] : (function () { throw new RuntimeError('Variable "envelope" does not exist.', 6, $this->source); })()), "type", [], "any", false, false, false, 6)))) {
            // line 7
            echo "    ";
            $context["title"] = "Error";
            // line 8
            echo "    ";
            $context["alert_class"] = "alert-danger";
            // line 9
            echo "    ";
            $context["progress_bg_color"] = "#721c24";
            // line 10
            echo "    ";
            $context["icon"] = "<svg class=\"bi flex-shrink-0 me-2\" width=\"24\" height=\"24\" role=\"img\" aria-label=\"Danger:\"><use xlink:href=\"#exclamation-triangle-fill\"/></svg>";
        } elseif ((0 === twig_compare("warning", twig_get_attribute($this->env, $this->source,         // line 11
(isset($context["envelope"]) || array_key_exists("envelope", $context) ? $context["envelope"] : (function () { throw new RuntimeError('Variable "envelope" does not exist.', 11, $this->source); })()), "type", [], "any", false, false, false, 11)))) {
            // line 12
            echo "    ";
            $context["title"] = "Warning";
            // line 13
            echo "    ";
            $context["alert_class"] = "alert-warning";
            // line 14
            echo "    ";
            $context["progress_bg_color"] = "#856404";
            // line 15
            echo "    ";
            $context["icon"] = "<svg class=\"bi flex-shrink-0 me-2\" width=\"24\" height=\"24\" role=\"img\" aria-label=\"Warning:\"><use xlink:href=\"#exclamation-triangle-fill\"/></svg>";
        } else {
            // line 17
            echo "    ";
            $context["title"] = "Info";
            // line 18
            echo "    ";
            $context["alert_class"] = "alert-info";
            // line 19
            echo "    ";
            $context["progress_bg_color"] = "#0c5460";
            // line 20
            echo "    ";
            $context["icon"] = "<svg class=\"bi flex-shrink-0 me-2\" width=\"24\" height=\"24\" role=\"img\" aria-label=\"Info:\"><use xlink:href=\"#info-fill\"/></svg>";
        }
        // line 22
        echo "
<div style=\"margin-top: 0.5rem;cursor: pointer;\">
    <svg xmlns=\"http://www.w3.org/2000/svg\" style=\"display: none;\">
        <symbol id=\"check-circle-fill\" fill=\"currentColor\" viewBox=\"0 0 16 16\">
            <path d=\"M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z\"/>
        </symbol>
        <symbol id=\"info-fill\" fill=\"currentColor\" viewBox=\"0 0 16 16\">
            <path d=\"M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z\"/>
        </symbol>
        <symbol id=\"exclamation-triangle-fill\" fill=\"currentColor\" viewBox=\"0 0 16 16\">
            <path d=\"M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z\"/>
        </symbol>
    </svg>
    <div class=\"alert ";
        // line 35
        echo twig_escape_filter($this->env, (isset($context["alert_class"]) || array_key_exists("alert_class", $context) ? $context["alert_class"] : (function () { throw new RuntimeError('Variable "alert_class" does not exist.', 35, $this->source); })()), "html", null, true);
        echo " text-break alert-dismissible fade in show align-items-center\" role=\"alert\" style=\"border-top-left-radius: 0;border-bottom-left-radius: 0;border: unset;border-left: 6px solid ";
        echo twig_escape_filter($this->env, (isset($context["progress_bg_color"]) || array_key_exists("progress_bg_color", $context) ? $context["progress_bg_color"] : (function () { throw new RuntimeError('Variable "progress_bg_color" does not exist.', 35, $this->source); })()), "html", null, true);
        echo "\">
        ";
        // line 36
        echo (isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 36, $this->source); })());
        echo "
        <strong>";
        // line 37
        echo twig_escape_filter($this->env, (((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["envelope"] ?? null), "notification", [], "any", false, true, false, 37), "title", [], "any", true, true, false, 37) &&  !(null === twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["envelope"] ?? null), "notification", [], "any", false, true, false, 37), "title", [], "any", false, false, false, 37)))) ? (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["envelope"] ?? null), "notification", [], "any", false, true, false, 37), "title", [], "any", false, false, false, 37)) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 37, $this->source); })())))), "html", null, true);
        echo "</strong> ";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, (isset($context["envelope"]) || array_key_exists("envelope", $context) ? $context["envelope"] : (function () { throw new RuntimeError('Variable "envelope" does not exist.', 37, $this->source); })()), "message", [], "any", false, false, false, 37)), "html", null, true);
        echo "
        <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\" aria-label=\"Close\" onclick=\"this.parentElement.remove()\"></button>
    </div>
    <div class=\"d-flex\" style=\"height: .125rem;margin-top: -1rem;\">
        <span class=\"flasher-progress\" style=\"background-color: ";
        // line 41
        echo twig_escape_filter($this->env, (isset($context["progress_bg_color"]) || array_key_exists("progress_bg_color", $context) ? $context["progress_bg_color"] : (function () { throw new RuntimeError('Variable "progress_bg_color" does not exist.', 41, $this->source); })()), "html", null, true);
        echo "\"></span>
    </div>
</div>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "@FlasherSymfony/bootstrap.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  133 => 41,  124 => 37,  120 => 36,  114 => 35,  99 => 22,  95 => 20,  92 => 19,  89 => 18,  86 => 17,  82 => 15,  79 => 14,  76 => 13,  73 => 12,  71 => 11,  68 => 10,  65 => 9,  62 => 8,  59 => 7,  57 => 6,  54 => 5,  51 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% if 'success' == envelope.type %}
    {% set title = 'Success' %}
    {% set alert_class = 'alert-success' %}
    {% set progress_bg_color = '#155724' %}
    {% set icon = '<svg class=\"bi flex-shrink-0 me-2\" width=\"24\" height=\"24\" role=\"img\" aria-label=\"Success:\"><use xlink:href=\"#check-circle-fill\"/></svg>' %}
{% elseif 'error' == envelope.type %}
    {% set title = 'Error' %}
    {% set alert_class = 'alert-danger' %}
    {% set progress_bg_color = '#721c24' %}
    {% set icon = '<svg class=\"bi flex-shrink-0 me-2\" width=\"24\" height=\"24\" role=\"img\" aria-label=\"Danger:\"><use xlink:href=\"#exclamation-triangle-fill\"/></svg>' %}
{% elseif 'warning' == envelope.type %}
    {% set title = 'Warning' %}
    {% set alert_class = 'alert-warning' %}
    {% set progress_bg_color = '#856404' %}
    {% set icon = '<svg class=\"bi flex-shrink-0 me-2\" width=\"24\" height=\"24\" role=\"img\" aria-label=\"Warning:\"><use xlink:href=\"#exclamation-triangle-fill\"/></svg>' %}
{% else %}
    {% set title = 'Info' %}
    {% set alert_class = 'alert-info' %}
    {% set progress_bg_color = '#0c5460' %}
    {% set icon = '<svg class=\"bi flex-shrink-0 me-2\" width=\"24\" height=\"24\" role=\"img\" aria-label=\"Info:\"><use xlink:href=\"#info-fill\"/></svg>' %}
{% endif %}

<div style=\"margin-top: 0.5rem;cursor: pointer;\">
    <svg xmlns=\"http://www.w3.org/2000/svg\" style=\"display: none;\">
        <symbol id=\"check-circle-fill\" fill=\"currentColor\" viewBox=\"0 0 16 16\">
            <path d=\"M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z\"/>
        </symbol>
        <symbol id=\"info-fill\" fill=\"currentColor\" viewBox=\"0 0 16 16\">
            <path d=\"M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z\"/>
        </symbol>
        <symbol id=\"exclamation-triangle-fill\" fill=\"currentColor\" viewBox=\"0 0 16 16\">
            <path d=\"M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z\"/>
        </symbol>
    </svg>
    <div class=\"alert {{ alert_class }} text-break alert-dismissible fade in show align-items-center\" role=\"alert\" style=\"border-top-left-radius: 0;border-bottom-left-radius: 0;border: unset;border-left: 6px solid {{ progress_bg_color }}\">
        {{ icon | raw }}
        <strong>{{ envelope.notification.title ?? title | trans }}</strong> {{ envelope.message | trans }}
        <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\" aria-label=\"Close\" onclick=\"this.parentElement.remove()\"></button>
    </div>
    <div class=\"d-flex\" style=\"height: .125rem;margin-top: -1rem;\">
        <span class=\"flasher-progress\" style=\"background-color: {{ progress_bg_color }}\"></span>
    </div>
</div>
", "@FlasherSymfony/bootstrap.html.twig", "C:\\Users\\malek\\Desktop\\wazzupwebapp\\vendor\\php-flasher\\flasher-symfony\\Resources\\views\\bootstrap.html.twig");
    }
}
