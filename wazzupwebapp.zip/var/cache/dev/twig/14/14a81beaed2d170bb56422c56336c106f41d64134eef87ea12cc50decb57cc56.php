<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* collab/index.html.twig */
class __TwigTemplate_41f6084f76c3c79e094ec7357eff65545c9d1da57b7e5f2fb4f4ca118ebaf718 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "collab/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "collab/index.html.twig"));

        // line 1
        $this->displayBlock('head', $context, $blocks);
        // line 40
        $this->loadTemplate("home/header.html.twig", "collab/index.html.twig", 40)->display($context);
        // line 41
        $this->loadTemplate("home/sidebar.html.twig", "collab/index.html.twig", 41)->display($context);
        // line 42
        $this->displayBlock('body', $context, $blocks);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 1
    public function block_head($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head"));

        // line 2
        echo "<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0,user-scalable=0,minimal-ui\">
    <meta name=\"author\" content=\"PIXINVENT\">
    <title>Wazzup Collaboration</title>
    <link rel=\"apple-touch-icon\" href=\"dashboard/app-assets/images/ico/apple-icon-120.png\">
    <link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"dashboard/app-assets/images/ico/favicon.ico\">
    <link href=\"https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;1,400;1,500;1,600\" rel=\"stylesheet\">

    <!-- BEGIN: Vendor CSS-->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/vendors/css/vendors.min.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/vendors/css/charts/apexcharts.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/vendors/css/extensions/toastr.min.css"), "html", null, true);
        echo "\">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/css/bootstrap.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/css/bootstrap-extended.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/css/colors.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/css/components.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/css/themes/dark-layout.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/css/themes/bordered-layout.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/css/themes/semi-dark-layout.css"), "html", null, true);
        echo "\">

    <!-- BEGIN: Page CSS-->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/css/core/menu/menu-types/vertical-menu.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/css/pages/dashboard-ecommerce.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/css/plugins/charts/chart-apex.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/css/plugins/extensions/ext-component-toastr.css"), "html", null, true);
        echo "\">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/assets/css/style.css"), "html", null, true);
        echo "\">
    <!-- END: Custom CSS-->

</head>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 42
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 43
        echo "<body class=\"vertical-layout vertical-menu-modern  navbar-floating footer-static  \" data-open=\"click\" data-menu=\"vertical-menu-modern\" data-col=\"\">

    <!-- BEGIN: Content-->
    <div class=\"app-content content \">
        <div class=\"content-overlay\"></div>
        <div class=\"header-navbar-shadow\"></div>
        <div class=\"content-wrapper\">
            <div class=\"content-header row\">
            </div>
            <div class=\"content-body\">
             <h4 class=\"card-title mb-50 mb-sm-0\" style = \"margin-left:2%\">Collaboration</h4>
            <br><br><br>
                        <div class=\"row mx-0\">
                 <!-- creer collab Card -->
                        <div class=\"col-lg-6 col-12\">
                            <div class=\"card card-revenue-budget\">
                                <div class=\"row mx-0\">
                                    <div class=\"col-md-7 col-12 revenue-report-wrapper\">
                                        <div class=\"d-sm-flex justify-content-between align-items-center mb-3\">
                                            <div class=\"d-flex align-items-center\">                                            
                                            </div>
                                        </div>
                                       <img src=\"";
        // line 65
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("collab/log-removebg-preview.png"), "html", null, true);
        echo "\" height =\"85%\" width=\"120%\" style = \"margin-left:-5%;margin-top:-10%\"alt=\"Logo\">    
                                    </div>
                                    <div class=\"col-md-5 col-12 budget-wrapper\">                                       
                                        <h4 class=\"card-title mb-50 mb-sm-0\">Créer une collaboration</h4>
                   <div style = \"margin-top:100%\">
                                           ";
        // line 70
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["collab_form"]) || array_key_exists("collab_form", $context) ? $context["collab_form"] : (function () { throw new RuntimeError('Variable "collab_form" does not exist.', 70, $this->source); })()), 'form_start', ["attr" => ["novalidate" => "novalidate"]]);
        echo "
\t\t\t\t        ";
        // line 71
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["collab_form"]) || array_key_exists("collab_form", $context) ? $context["collab_form"] : (function () { throw new RuntimeError('Variable "collab_form" does not exist.', 71, $this->source); })()), 'errors');
        echo "
\t\t\t\t<div class=\"form-wrapper\">
\t\t\t\t\t";
        // line 74
        echo "\t\t\t\t\t";
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["collab_form"]) || array_key_exists("collab_form", $context) ? $context["collab_form"] : (function () { throw new RuntimeError('Variable "collab_form" does not exist.', 74, $this->source); })()), "nomCollab", [], "any", false, false, false, 74), 'row', ["attr" => ["class" => "form-control", "placeholder" => "Wazzup"]]);
        echo "
\t\t\t\t\t
\t\t\t\t</div>
\t\t\t\t<br><br>
                <div style = \"margin-bottom:-12%\">";
        // line 78
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["collab_form"]) || array_key_exists("collab_form", $context) ? $context["collab_form"] : (function () { throw new RuntimeError('Variable "collab_form" does not exist.', 78, $this->source); })()), "Submit", [], "any", false, false, false, 78), 'row', ["label" => "Créer", "attr" => ["class" => "btn btn-primary"]]);
        echo " </div>
\t\t
\t\t ";
        // line 80
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["collab_form"]) || array_key_exists("collab_form", $context) ? $context["collab_form"] : (function () { throw new RuntimeError('Variable "collab_form" does not exist.', 80, $this->source); })()), 'form_end');
        echo "   </div>                                   
                                    </div>
                                </div>
                            </div>
                        </div>
                  <!--/ creer collab Card -->
                  <!-- Lister collab Card -->
                        <div class=\"col-lg-6 col-12\">
                            <div class=\"card card-revenue-budget\">
                                <div class=\"row mx-0\">
                                    <div class=\"col-md-7 col-12 revenue-report-wrapper\">
                                        <div class=\"d-sm-flex justify-content-between align-items-center mb-3\">
                                            <div class=\"d-flex align-items-center\">                                            
                                            </div>
                                        </div>
                                   <img src=\"";
        // line 95
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("collab/globe.png"), "html", null, true);
        echo "\" height =\"80%\" width=\"170%\" style = \"margin-left:-30%\" alt=\"Logo\"> 
                                    </div>
                                    <div class=\"col-md-5 col-12 budget-wrapper\">                                       
                                        <h4 class=\"card-title mb-50 mb-sm-0\">Lister vos collaboration</h4><a  href=\"";
        // line 98
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_list_collab");
        echo "\">
                                        <button type=\"button\" class=\"btn btn-primary\" style = \"margin-top:165%\">Afficher</button></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--/ Lister collab Card -->
                        </div>




            </div>
        </div>
    </div>
    <!-- END: Content-->

    <div class=\"sidenav-overlay\"></div>
    <div class=\"drag-target\"></div>

    <!-- BEGIN: Footer-->
    <footer class=\"footer footer-static footer-light\">
        <p class=\"clearfix mb-0\"><span class=\"float-md-left d-block d-md-inline-block mt-25\">COPYRIGHT &copy; 2022<a class=\"ml-25\"  target=\"_blank\"></a><span class=\"d-none d-sm-inline-block\">, All rights Reserved Wazzup</span></span><span class=\"float-md-right d-none d-md-block\"></span></p>
    </footer>
    <button class=\"btn btn-primary btn-icon scroll-top\" type=\"button\"><i data-feather=\"arrow-up\"></i></button>
    <!-- END: Footer-->


    <!-- BEGIN: Vendor JS-->
    <script src=\"dashboard/app-assets/vendors/js/vendors.min.js\"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src=\"dashboard/app-assets/vendors/js/charts/apexcharts.min.js\"></script>
    <script src=\"dashboard/app-assets/vendors/js/extensions/toastr.min.js\"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src=\"dashboard/app-assets/js/core/app-menu.js\"></script>
    <script src=\"dashboard/app-assets/js/core/app.js\"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src=\"dashboard/app-assets/js/scripts/pages/dashboard-ecommerce.js\"></script>
    <!-- END: Page JS-->

    <script>
        \$(window).on('load', function() {
            if (feather) {
                feather.replace({
                    width: 14,
                    height: 14
                });
            }
        })
    </script>
</body>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "collab/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  251 => 98,  245 => 95,  227 => 80,  222 => 78,  214 => 74,  209 => 71,  205 => 70,  197 => 65,  173 => 43,  163 => 42,  148 => 35,  141 => 31,  137 => 30,  133 => 29,  129 => 28,  123 => 25,  119 => 24,  115 => 23,  111 => 22,  107 => 21,  103 => 20,  99 => 19,  92 => 15,  88 => 14,  84 => 13,  71 => 2,  61 => 1,  51 => 42,  49 => 41,  47 => 40,  45 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% block head %}
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0,user-scalable=0,minimal-ui\">
    <meta name=\"author\" content=\"PIXINVENT\">
    <title>Wazzup Collaboration</title>
    <link rel=\"apple-touch-icon\" href=\"dashboard/app-assets/images/ico/apple-icon-120.png\">
    <link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"dashboard/app-assets/images/ico/favicon.ico\">
    <link href=\"https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;1,400;1,500;1,600\" rel=\"stylesheet\">

    <!-- BEGIN: Vendor CSS-->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/app-assets/vendors/css/vendors.min.css')}}\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/app-assets/vendors/css/charts/apexcharts.css')}}\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/app-assets/vendors/css/extensions/toastr.min.css')}}\">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/app-assets/css/bootstrap.css')}}\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/app-assets/css/bootstrap-extended.css')}}\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/app-assets/css/colors.css')}}\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/app-assets/css/components.css')}}\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/app-assets/css/themes/dark-layout.css')}}\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/app-assets/css/themes/bordered-layout.css')}}\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/app-assets/css/themes/semi-dark-layout.css')}}\">

    <!-- BEGIN: Page CSS-->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/app-assets/css/core/menu/menu-types/vertical-menu.css')}}\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/app-assets/css/pages/dashboard-ecommerce.css')}}\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/app-assets/css/plugins/charts/chart-apex.css')}}\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/app-assets/css/plugins/extensions/ext-component-toastr.css')}}\">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/assets/css/style.css')}}\">
    <!-- END: Custom CSS-->

</head>
{% endblock %}
{% include 'home/header.html.twig' %}
{% include 'home/sidebar.html.twig' %}
{% block body %}
<body class=\"vertical-layout vertical-menu-modern  navbar-floating footer-static  \" data-open=\"click\" data-menu=\"vertical-menu-modern\" data-col=\"\">

    <!-- BEGIN: Content-->
    <div class=\"app-content content \">
        <div class=\"content-overlay\"></div>
        <div class=\"header-navbar-shadow\"></div>
        <div class=\"content-wrapper\">
            <div class=\"content-header row\">
            </div>
            <div class=\"content-body\">
             <h4 class=\"card-title mb-50 mb-sm-0\" style = \"margin-left:2%\">Collaboration</h4>
            <br><br><br>
                        <div class=\"row mx-0\">
                 <!-- creer collab Card -->
                        <div class=\"col-lg-6 col-12\">
                            <div class=\"card card-revenue-budget\">
                                <div class=\"row mx-0\">
                                    <div class=\"col-md-7 col-12 revenue-report-wrapper\">
                                        <div class=\"d-sm-flex justify-content-between align-items-center mb-3\">
                                            <div class=\"d-flex align-items-center\">                                            
                                            </div>
                                        </div>
                                       <img src=\"{{ asset('collab/log-removebg-preview.png') }}\" height =\"85%\" width=\"120%\" style = \"margin-left:-5%;margin-top:-10%\"alt=\"Logo\">    
                                    </div>
                                    <div class=\"col-md-5 col-12 budget-wrapper\">                                       
                                        <h4 class=\"card-title mb-50 mb-sm-0\">Créer une collaboration</h4>
                   <div style = \"margin-top:100%\">
                                           {{ form_start(collab_form,{attr:{'novalidate':'novalidate'}}) }}
\t\t\t\t        {{ form_errors(collab_form) }}
\t\t\t\t<div class=\"form-wrapper\">
\t\t\t\t\t{# <input type=\"text\" placeholder=\"Nom\" class=\"form-control\"> #}
\t\t\t\t\t{{form_row(collab_form.nomCollab,{'attr': {'class': 'form-control','placeholder':'Wazzup'}})}}
\t\t\t\t\t
\t\t\t\t</div>
\t\t\t\t<br><br>
                <div style = \"margin-bottom:-12%\">{{ form_row(collab_form.Submit, { 'label': 'Créer', 'attr':{'class':'btn btn-primary' } }) }} </div>
\t\t
\t\t {{ form_end(collab_form) }}   </div>                                   
                                    </div>
                                </div>
                            </div>
                        </div>
                  <!--/ creer collab Card -->
                  <!-- Lister collab Card -->
                        <div class=\"col-lg-6 col-12\">
                            <div class=\"card card-revenue-budget\">
                                <div class=\"row mx-0\">
                                    <div class=\"col-md-7 col-12 revenue-report-wrapper\">
                                        <div class=\"d-sm-flex justify-content-between align-items-center mb-3\">
                                            <div class=\"d-flex align-items-center\">                                            
                                            </div>
                                        </div>
                                   <img src=\"{{ asset('collab/globe.png') }}\" height =\"80%\" width=\"170%\" style = \"margin-left:-30%\" alt=\"Logo\"> 
                                    </div>
                                    <div class=\"col-md-5 col-12 budget-wrapper\">                                       
                                        <h4 class=\"card-title mb-50 mb-sm-0\">Lister vos collaboration</h4><a  href=\"{{ path('app_list_collab') }}\">
                                        <button type=\"button\" class=\"btn btn-primary\" style = \"margin-top:165%\">Afficher</button></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--/ Lister collab Card -->
                        </div>




            </div>
        </div>
    </div>
    <!-- END: Content-->

    <div class=\"sidenav-overlay\"></div>
    <div class=\"drag-target\"></div>

    <!-- BEGIN: Footer-->
    <footer class=\"footer footer-static footer-light\">
        <p class=\"clearfix mb-0\"><span class=\"float-md-left d-block d-md-inline-block mt-25\">COPYRIGHT &copy; 2022<a class=\"ml-25\"  target=\"_blank\"></a><span class=\"d-none d-sm-inline-block\">, All rights Reserved Wazzup</span></span><span class=\"float-md-right d-none d-md-block\"></span></p>
    </footer>
    <button class=\"btn btn-primary btn-icon scroll-top\" type=\"button\"><i data-feather=\"arrow-up\"></i></button>
    <!-- END: Footer-->


    <!-- BEGIN: Vendor JS-->
    <script src=\"dashboard/app-assets/vendors/js/vendors.min.js\"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src=\"dashboard/app-assets/vendors/js/charts/apexcharts.min.js\"></script>
    <script src=\"dashboard/app-assets/vendors/js/extensions/toastr.min.js\"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src=\"dashboard/app-assets/js/core/app-menu.js\"></script>
    <script src=\"dashboard/app-assets/js/core/app.js\"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src=\"dashboard/app-assets/js/scripts/pages/dashboard-ecommerce.js\"></script>
    <!-- END: Page JS-->

    <script>
        \$(window).on('load', function() {
            if (feather) {
                feather.replace({
                    width: 14,
                    height: 14
                });
            }
        })
    </script>
</body>

{% endblock %}", "collab/index.html.twig", "C:\\Users\\malek\\Desktop\\wazzupwebapp\\templates\\collab\\index.html.twig");
    }
}
