<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* signup/index.html.twig */
class __TwigTemplate_1eeae1d2a385224ad7700e8edbb0d385835dbfcb966eda7a320b33c93514a55a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "signup/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "signup/index.html.twig"));

        // line 1
        $this->displayBlock('head', $context, $blocks);
        // line 17
        $this->loadTemplate("navbar/nav.html.twig", "signup/index.html.twig", 17)->display($context);
        // line 18
        $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme((isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 18, $this->source); })()), [0 => "bootstrap_4_layout.html.twig"], true);
        // line 19
        $this->displayBlock('body', $context, $blocks);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 1
    public function block_head($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head"));

        // line 2
        echo "<head>
\t<meta charset=\"utf-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
\t<link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("signup/fonts/material-design-iconic-font/css/material-design-iconic-font.min.css"), "html", null, true);
        echo "\">
\t<!-- FONT AWESOME (LOCAL) -->
\t<link href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("signup/fa/css/all.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
\t<!-- BOOTSTRAP (LOCAL) -->
\t<link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("signup/css/bootstrap.min.css"), "html", null, true);
        echo "\">
\t<!-- STYLE CSS -->
\t<link rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("signup/css/style.css"), "html", null, true);
        echo "\">
\t<link rel=\"shortcut icon\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("signup/img/favicon.ico"), "html", null, true);
        echo "\">
\t<script src=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("signup/js/Jquery.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("signup/js/form.js"), "html", null, true);
        echo "\"></script>
</head>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 19
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 20
        echo "<body>

\t<div id=\"part\" class=\"wrapper\">
\t\t<div id=\"particles-js\"></div>
        <!-- Latest compiled and minified JavaScript -->
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js\" integrity=\"sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa\" crossorigin=\"anonymous\"></script>
\t\t<script src='https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js'></script>
\t\t<script src=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("signup/js/app.js"), "html", null, true);
        echo "\"></script>
\t\t<div class=\"inner\">
\t\t\t<div class=\"image-holder\"><br><br><br>
         <img style=\"height: 65vh;\" src=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("signup/img/logo.png"), "html", null, true);
        echo "\" alt=\"logo_wazzup\">
\t\t\t</div>
\t\t";
        // line 32
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 32, $this->source); })()), 'form_start', ["attr" => ["novalidate" => "novalidate"]]);
        echo "
\t\t\t\t<h3 class=\"signup-titre\"><i class=\"fas fa-user-edit\"></i>&nbsp;&nbsp;S'inscrire</h3>
\t\t\t\t<h5>CREER UN COMPTE</h5><br>
\t\t";
        // line 35
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 35, $this->source); })()), "flashes", [0 => "success"], "method", false, false, false, 35));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 36
            echo "           <div class=\"alert alert-success\">
\t\t   ";
            // line 37
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "
\t\t   </div>
\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        echo "\t\t\t\t<div class=\"form-wrapper\">
\t\t\t\t\t";
        // line 41
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 41, $this->source); })()), "nom", [], "any", false, false, false, 41), 'widget', ["label" => "Nom", "attr" => ["class" => "form-control", "placeholder" => "Votre nom"]]);
        echo "
\t\t\t\t\t<i style=\"display:fixed;\" class=\"zmdi zmdi-account\"></i>
\t\t\t\t</div>
\t\t\t\t";
        // line 44
        if ($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 44, $this->source); })()), "nom", [], "any", false, false, false, 44), 'errors')) {
            // line 45
            echo "\t\t\t\t";
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 45, $this->source); })()), "nom", [], "any", false, false, false, 45), 'errors');
            echo "
\t\t\t\t";
        }
        // line 47
        echo "                <div class=\"form-wrapper\">
\t\t\t\t\t";
        // line 48
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 48, $this->source); })()), "prenom", [], "any", false, false, false, 48), 'widget', ["label" => "Prenom", "attr" => ["class" => "form-control", "placeholder" => "Votre prenom"]]);
        echo "
\t\t\t\t\t<i class=\"zmdi zmdi-account\"></i>
\t\t\t\t</div>
\t\t\t\t";
        // line 51
        if ($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 51, $this->source); })()), "prenom", [], "any", false, false, false, 51), 'errors')) {
            // line 52
            echo "\t\t\t\t\t";
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 52, $this->source); })()), "prenom", [], "any", false, false, false, 52), 'errors');
            echo "
\t\t\t\t";
        }
        // line 54
        echo "\t\t\t\t<div class=\"form-wrapper\">
\t\t\t\t\t";
        // line 55
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 55, $this->source); })()), "email", [], "any", false, false, false, 55), 'widget', ["label" => "Email", "attr" => ["class" => "form-control", "placeholder" => "utilisateur@wazzup.com"]]);
        echo "
\t\t\t\t\t<i class=\"zmdi zmdi-email\"></i>
\t\t\t\t</div>
\t\t\t\t";
        // line 58
        if ($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 58, $this->source); })()), "email", [], "any", false, false, false, 58), 'errors')) {
            // line 59
            echo "\t\t        ";
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 59, $this->source); })()), "email", [], "any", false, false, false, 59), 'errors');
            echo "
\t\t\t   ";
        }
        // line 61
        echo "\t\t\t\t<div class=\"form-wrapper\">
\t\t\t\t\t";
        // line 62
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 62, $this->source); })()), "mdp", [], "any", false, false, false, 62), 'widget', ["label" => "Mot de passe", "attr" => ["label" => "", "class" => "form-control", "placeholder" => "Mot de passe"]]);
        echo "
\t\t\t\t\t<i class=\"zmdi zmdi-lock\"></i>
\t\t\t\t</div>
\t\t\t\t";
        // line 65
        if ($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 65, $this->source); })()), "mdp", [], "any", false, false, false, 65), 'errors')) {
            // line 66
            echo "\t\t\t\t";
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 66, $this->source); })()), "mdp", [], "any", false, false, false, 66), 'errors');
            echo "
\t\t\t\t";
        }
        // line 68
        echo "\t\t\t\t<div class=\"form-wrapper\">
\t\t\t\t\t";
        // line 69
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 69, $this->source); })()), "mdpconfirm", [], "any", false, false, false, 69), 'widget', ["label" => "Confirmation", "attr" => ["class" => "form-control", "placeholder" => "Confirmer votre mot de passe"]]);
        echo "
\t\t\t\t\t<i class=\"zmdi zmdi-lock\"></i>
\t\t\t\t</div>
\t\t\t\t";
        // line 72
        if ($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 72, $this->source); })()), "mdpconfirm", [], "any", false, false, false, 72), 'errors')) {
            // line 73
            echo "\t\t\t\t";
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 73, $this->source); })()), "mdpconfirm", [], "any", false, false, false, 73), 'errors');
            echo "
\t\t\t\t";
        }
        // line 75
        echo "\t\t\t\t<div class=\"form-wrapper\">
\t\t\t\t\t";
        // line 76
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 76, $this->source); })()), "numTel", [], "any", false, false, false, 76), 'widget', ["label" => "Numero de telephone", "attr" => ["class" => "form-control", "placeholder" => "Numero de telephone"]]);
        echo "
\t\t\t\t\t<i class=\"zmdi zmdi-phone\" style=\"font-size: 17px\"></i>
\t\t\t\t</div>
\t\t\t\t";
        // line 79
        if ($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 79, $this->source); })()), "numTel", [], "any", false, false, false, 79), 'errors')) {
            // line 80
            echo "\t\t\t\t\t";
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 80, $this->source); })()), "numTel", [], "any", false, false, false, 80), 'errors');
            echo "
\t\t\t\t";
        }
        // line 82
        echo "\t\t\t\t<div class=\"form-wrapper\">
\t\t\t\t";
        // line 83
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 83, $this->source); })()), "genre", [], "any", false, false, false, 83), 'widget', ["label" => "Genre", "attr" => ["class" => "form-control", "placeholder" => "Genre"]]);
        echo "
                    <i class=\"zmdi zmdi-accounts-alt\"></i>
\t\t\t\t</div>
                
\t\t\t\t";
        // line 87
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 87, $this->source); })()), "datenaissance", [], "any", false, false, false, 87), 'widget', ["label" => "Date de naissance", "attr" => ["class" => "datepicker form-control"]]);
        echo "
\t\t\t\t";
        // line 88
        if ($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 88, $this->source); })()), "datenaissance", [], "any", false, false, false, 88), 'errors')) {
            // line 89
            echo "\t\t\t\t\t";
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 89, $this->source); })()), "datenaissance", [], "any", false, false, false, 89), 'errors');
            echo "
\t\t\t\t";
        }
        // line 91
        echo "\t\t\t\t
\t\t    \t
\t\t\t\t";
        // line 101
        echo "               ";
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 101, $this->source); })()), "Submit", [], "any", false, false, false, 101), 'widget', ["label" => "Soumettre", "attr" => ["class" => "ld-over-full-inverse"]]);
        echo "
\t\t\t ";
        // line 102
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["signup_form"]) || array_key_exists("signup_form", $context) ? $context["signup_form"] : (function () { throw new RuntimeError('Variable "signup_form" does not exist.', 102, $this->source); })()), 'form_end');
        echo "
\t\t</div>
\t</div>
\t";
        // line 105
        echo $this->extensions['Flasher\Symfony\Twig\FlasherTwigExtension']->flasherRender();
        echo "
</body>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "signup/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  307 => 105,  301 => 102,  296 => 101,  292 => 91,  286 => 89,  284 => 88,  280 => 87,  273 => 83,  270 => 82,  264 => 80,  262 => 79,  256 => 76,  253 => 75,  247 => 73,  245 => 72,  239 => 69,  236 => 68,  230 => 66,  228 => 65,  222 => 62,  219 => 61,  213 => 59,  211 => 58,  205 => 55,  202 => 54,  196 => 52,  194 => 51,  188 => 48,  185 => 47,  179 => 45,  177 => 44,  171 => 41,  168 => 40,  159 => 37,  156 => 36,  152 => 35,  146 => 32,  141 => 30,  135 => 27,  126 => 20,  116 => 19,  103 => 14,  99 => 13,  95 => 12,  91 => 11,  86 => 9,  81 => 7,  76 => 5,  71 => 2,  61 => 1,  51 => 19,  49 => 18,  47 => 17,  45 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% block head %}
<head>
\t<meta charset=\"utf-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
\t<link rel=\"stylesheet\" href=\"{{ asset('signup/fonts/material-design-iconic-font/css/material-design-iconic-font.min.css') }}\">
\t<!-- FONT AWESOME (LOCAL) -->
\t<link href=\"{{ asset('signup/fa/css/all.css') }}\" rel=\"stylesheet\">
\t<!-- BOOTSTRAP (LOCAL) -->
\t<link rel=\"stylesheet\" href=\"{{ asset('signup/css/bootstrap.min.css') }}\">
\t<!-- STYLE CSS -->
\t<link rel=\"stylesheet\" href=\"{{ asset('signup/css/style.css') }}\">
\t<link rel=\"shortcut icon\" href=\"{{ asset('signup/img/favicon.ico') }}\">
\t<script src=\"{{ asset('signup/js/Jquery.js') }}\"></script>
\t<script src=\"{{ asset('signup/js/form.js') }}\"></script>
</head>
{% endblock %}
{% include 'navbar/nav.html.twig' %}
{% form_theme signup_form 'bootstrap_4_layout.html.twig' %}
{% block body %}
<body>

\t<div id=\"part\" class=\"wrapper\">
\t\t<div id=\"particles-js\"></div>
        <!-- Latest compiled and minified JavaScript -->
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js\" integrity=\"sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa\" crossorigin=\"anonymous\"></script>
\t\t<script src='https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js'></script>
\t\t<script src=\"{{ asset('signup/js/app.js') }}\"></script>
\t\t<div class=\"inner\">
\t\t\t<div class=\"image-holder\"><br><br><br>
         <img style=\"height: 65vh;\" src=\"{{ asset('signup/img/logo.png') }}\" alt=\"logo_wazzup\">
\t\t\t</div>
\t\t{{ form_start(signup_form,{attr:{'novalidate':'novalidate'}}) }}
\t\t\t\t<h3 class=\"signup-titre\"><i class=\"fas fa-user-edit\"></i>&nbsp;&nbsp;S'inscrire</h3>
\t\t\t\t<h5>CREER UN COMPTE</h5><br>
\t\t{% for message in app.flashes('success') %}
           <div class=\"alert alert-success\">
\t\t   {{ message }}
\t\t   </div>
\t\t{% endfor %}
\t\t\t\t<div class=\"form-wrapper\">
\t\t\t\t\t{{form_widget(signup_form.nom,{'label': 'Nom','attr':{'class':'form-control','placeholder':'Votre nom'}})}}
\t\t\t\t\t<i style=\"display:fixed;\" class=\"zmdi zmdi-account\"></i>
\t\t\t\t</div>
\t\t\t\t{% if form_errors(signup_form.nom) %}
\t\t\t\t{{ form_errors(signup_form.nom) }}
\t\t\t\t{% endif %}
                <div class=\"form-wrapper\">
\t\t\t\t\t{{form_widget(signup_form.prenom,{'label': 'Prenom','attr':{'class':'form-control','placeholder':'Votre prenom'}})}}
\t\t\t\t\t<i class=\"zmdi zmdi-account\"></i>
\t\t\t\t</div>
\t\t\t\t{% if form_errors(signup_form.prenom) %}
\t\t\t\t\t{{ form_errors(signup_form.prenom) }}
\t\t\t\t{% endif %}
\t\t\t\t<div class=\"form-wrapper\">
\t\t\t\t\t{{form_widget(signup_form.email,{'label': 'Email','attr':{'class':'form-control','placeholder':'utilisateur@wazzup.com'}})}}
\t\t\t\t\t<i class=\"zmdi zmdi-email\"></i>
\t\t\t\t</div>
\t\t\t\t{% if form_errors(signup_form.email) %}
\t\t        {{ form_errors(signup_form.email) }}
\t\t\t   {% endif %}
\t\t\t\t<div class=\"form-wrapper\">
\t\t\t\t\t{{form_widget(signup_form.mdp,{'label': 'Mot de passe','attr': {'label':'','class': 'form-control','placeholder':'Mot de passe'}})}}
\t\t\t\t\t<i class=\"zmdi zmdi-lock\"></i>
\t\t\t\t</div>
\t\t\t\t{% if form_errors(signup_form.mdp) %}
\t\t\t\t{{ form_errors(signup_form.mdp) }}
\t\t\t\t{% endif %}
\t\t\t\t<div class=\"form-wrapper\">
\t\t\t\t\t{{form_widget(signup_form.mdpconfirm,{'label': 'Confirmation','attr': {'class': 'form-control','placeholder':'Confirmer votre mot de passe'}})}}
\t\t\t\t\t<i class=\"zmdi zmdi-lock\"></i>
\t\t\t\t</div>
\t\t\t\t{% if form_errors(signup_form.mdpconfirm) %}
\t\t\t\t{{ form_errors(signup_form.mdpconfirm) }}
\t\t\t\t{% endif %}
\t\t\t\t<div class=\"form-wrapper\">
\t\t\t\t\t{{form_widget(signup_form.numTel,{'label': 'Numero de telephone','attr': {'class': 'form-control','placeholder':'Numero de telephone'}})}}
\t\t\t\t\t<i class=\"zmdi zmdi-phone\" style=\"font-size: 17px\"></i>
\t\t\t\t</div>
\t\t\t\t{% if form_errors(signup_form.numTel) %}
\t\t\t\t\t{{ form_errors(signup_form.numTel) }}
\t\t\t\t{% endif %}
\t\t\t\t<div class=\"form-wrapper\">
\t\t\t\t{{form_widget(signup_form.genre,{'label': 'Genre','attr': {'class': 'form-control','placeholder':'Genre'}})}}
                    <i class=\"zmdi zmdi-accounts-alt\"></i>
\t\t\t\t</div>
                
\t\t\t\t{{form_widget(signup_form.datenaissance,{'label': 'Date de naissance','attr': {'class': 'datepicker form-control'}})}}
\t\t\t\t{% if form_errors(signup_form.datenaissance) %}
\t\t\t\t\t{{ form_errors(signup_form.datenaissance) }}
\t\t\t\t{% endif %}
\t\t\t\t
\t\t    \t
\t\t\t\t{# <div class=\"form-group\">
\t\t\t\t\t<div class=\"custom-file\">
\t\t\t\t\t\t{{form_row(signup_form.avatar,{'label': 'Votre image','attr': {'class': 'custom-file-input'}})}}
\t\t\t\t\t\t<label class=\"custom-file-label\" for=\"customFile\">Choisir un fichier</label>
\t\t\t\t\t</div>
\t\t\t\t\t&nbsp;&nbsp;<i class=\"zmdi zmdi-attachment-alt\"></i>

\t\t\t\t</div> #}
               {{ form_widget(signup_form.Submit, { 'label': 'Soumettre', 'attr':{'class':'ld-over-full-inverse'} }) }}
\t\t\t {{ form_end(signup_form) }}
\t\t</div>
\t</div>
\t{{ flasher_render() }}
</body>
{% endblock %}", "signup/index.html.twig", "C:\\Users\\malek\\Desktop\\wazzupwebapp\\templates\\signup\\index.html.twig");
    }
}
