<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* activation/error.html.twig */
class __TwigTemplate_6613d7c1f703a663fb6fec5e7bc2cfac1e63e0a443325c7257b6d9e6234a6caa extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "activation/error.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "activation/error.html.twig"));

        // line 1
        echo "<!-- BEGIN: Head-->
";
        // line 2
        $this->displayBlock('head', $context, $blocks);
        // line 50
        echo "  <!-- END: Head-->

  <!-- BEGIN: Body-->
  ";
        // line 53
        $this->displayBlock('body', $context, $blocks);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_head($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head"));

        // line 3
        echo "  <head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"author\" content=\"MINDUNITS\">
    <title>Wazzup - 404</title>
    <link href=\"https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;1,400;1,500;1,600\" rel=\"stylesheet\">
\t<link rel=\"shortcut icon\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("signup/img/favicon.ico"), "html", null, true);
        echo "\">

    <!-- BEGIN: Vendor CSS-->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/vendors/css/vendors.min.css"), "html", null, true);
        echo "\">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/css/bootstrap.min.css"), "html", null, true);
        echo "\">
    
    <!-- BEGIN: Page CSS-->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/css/core/menu/menu-types/vertical-menu.min.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/css/pages/page-misc.min.css"), "html", null, true);
        echo "\">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/assets/css/style.css"), "html", null, true);
        echo "\">
    <!-- END: Custom CSS-->
   <style>
   .error-msg{
     color:white;
     display:block;
   }
   .error-text{

   }
   .misc-wrapper .brand-logo{

    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    /* position: fixed; */
    top: 2rem;
    left: 2rem;
    margin: 0;
   }

   </style>

  </head>
  ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 53
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 54
        echo "  <body class=\"vertical-layout vertical-menu-modern blank-page navbar-floating footer-static  \" data-open=\"click\" data-menu=\"vertical-menu-modern\" data-col=\"blank-page\">
    <!-- BEGIN: Content-->
    <div class=\"app-content content \" style=\"background:linear-gradient(90deg, rgba(0,119,119,1) 64%, rgba(200,200,200,1) 100%);\">
  <div class=\"misc-wrapper\"><a class=\"brand-logo\" href=\"javascript:void(0);\">
             <img style=\"height: 18vh;\" src=\"";
        // line 58
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("signup/img/logo.png"), "html", null, true);
        echo "\" alt=\"logo_wazzup\">
             </a>
                    <div class=\"content-body\">
          <!-- Error page-->
        
            <div class=\"misc-inner p-2 p-sm-3\">
              <div class=\"w-100 text-center\">
                <h2 class=\"error-msg\">Oops! 😖 L'URL demandé n'existe pas !</h2>
                <a class=\"btn btn-primary return-btn\" href=\"";
        // line 66
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_auth");
        echo "\">Revenir</a>
              <img class=\"img-fluid\" src=\"dashboard/app-assets/images/pages/error.svg\" alt=\"Error page\"/>
              </div>
         
          <!-- / Error page-->
        </div>
      </div>
             </div>
        
 
    
    <script src=\"";
        // line 77
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/vendors/js/vendors.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 78
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/js/core/app-menu.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 79
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/app-assets/js/core/app.min.js"), "html", null, true);
        echo "\"></script>



    <script>
      \$(window).on('load',  function(){
        if (feather) {
          feather.replace({ width: 14, height: 14 });
        }
      })
    </script>
  </body>
  ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "activation/error.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  198 => 79,  194 => 78,  190 => 77,  176 => 66,  165 => 58,  159 => 54,  149 => 53,  113 => 24,  106 => 20,  102 => 19,  96 => 16,  89 => 12,  83 => 9,  75 => 3,  65 => 2,  55 => 53,  50 => 50,  48 => 2,  45 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!-- BEGIN: Head-->
{% block head %}
  <head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"author\" content=\"MINDUNITS\">
    <title>Wazzup - 404</title>
    <link href=\"https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;1,400;1,500;1,600\" rel=\"stylesheet\">
\t<link rel=\"shortcut icon\" href=\"{{ asset('signup/img/favicon.ico') }}\">

    <!-- BEGIN: Vendor CSS-->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/app-assets/vendors/css/vendors.min.css')}}\">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/app-assets/css/bootstrap.min.css')}}\">
    
    <!-- BEGIN: Page CSS-->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/app-assets/css/core/menu/menu-types/vertical-menu.min.css')}}\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/app-assets/css/pages/page-misc.min.css')}}\">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('dashboard/assets/css/style.css')}}\">
    <!-- END: Custom CSS-->
   <style>
   .error-msg{
     color:white;
     display:block;
   }
   .error-text{

   }
   .misc-wrapper .brand-logo{

    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    /* position: fixed; */
    top: 2rem;
    left: 2rem;
    margin: 0;
   }

   </style>

  </head>
  {% endblock %}
  <!-- END: Head-->

  <!-- BEGIN: Body-->
  {% block body %}
  <body class=\"vertical-layout vertical-menu-modern blank-page navbar-floating footer-static  \" data-open=\"click\" data-menu=\"vertical-menu-modern\" data-col=\"blank-page\">
    <!-- BEGIN: Content-->
    <div class=\"app-content content \" style=\"background:linear-gradient(90deg, rgba(0,119,119,1) 64%, rgba(200,200,200,1) 100%);\">
  <div class=\"misc-wrapper\"><a class=\"brand-logo\" href=\"javascript:void(0);\">
             <img style=\"height: 18vh;\" src=\"{{asset('signup/img/logo.png')}}\" alt=\"logo_wazzup\">
             </a>
                    <div class=\"content-body\">
          <!-- Error page-->
        
            <div class=\"misc-inner p-2 p-sm-3\">
              <div class=\"w-100 text-center\">
                <h2 class=\"error-msg\">Oops! 😖 L'URL demandé n'existe pas !</h2>
                <a class=\"btn btn-primary return-btn\" href=\"{{path('app_auth')}}\">Revenir</a>
              <img class=\"img-fluid\" src=\"dashboard/app-assets/images/pages/error.svg\" alt=\"Error page\"/>
              </div>
         
          <!-- / Error page-->
        </div>
      </div>
             </div>
        
 
    
    <script src=\"{{asset('dashboard/app-assets/vendors/js/vendors.min.js')}}\"></script>
    <script src=\"{{asset('dashboard/app-assets/js/core/app-menu.min.js')}}\"></script>
    <script src=\"{{asset('dashboard/app-assets/js/core/app.min.js')}}\"></script>



    <script>
      \$(window).on('load',  function(){
        if (feather) {
          feather.replace({ width: 14, height: 14 });
        }
      })
    </script>
  </body>
  {% endblock %}", "activation/error.html.twig", "C:\\Users\\malek\\Desktop\\wazzupwebapp\\templates\\activation\\error.html.twig");
    }
}
