<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* activation/activated.html.twig */
class __TwigTemplate_3f1003e61b0eb649ea606344983ae99fff11645695a047eedb211e649a40f406 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "activation/activated.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "activation/activated.html.twig"));

        // line 1
        $this->displayBlock('head', $context, $blocks);
        // line 9
        $this->displayBlock('body', $context, $blocks);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 1
    public function block_head($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head"));

        // line 2
        echo "<meta charset=\"utf-8\">
\t<!-- STYLE CSS -->
\t<link rel=\"stylesheet\" href=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("activation/css/style.css"), "html", null, true);
        echo "\">
    <link rel=\"shortcut icon\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("signup/img/favicon.ico"), "html", null, true);
        echo "\">
\t<script src=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("activation/js/script.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("signup/js/Jquery.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 9
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div id=\"part\" class=\"wrapper\">
\t<div id=\"particles-js\"></div>
     <!-- Latest compiled and minified JavaScript -->
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js\" integrity=\"sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa\" crossorigin=\"anonymous\"></script>
\t\t<script src='https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js'></script>
\t\t<script src=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("signup/js/app.js"), "html", null, true);
        echo "\"></script>


<div class=\"logo\">
  <div></div>
  <div></div>
  <div></div>
  <svg viewBox=\"0 0 200 300\">
   <img style=\"height: 25vh;\" src=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("signup/img/logo.png"), "html", null, true);
        echo "\" alt=\"logo_wazzup\">
   </svg>
</div>
<div class=\"sidebar\">

\t\t<ul>
\t\t\t<li class=\"notification notification-activated\">
\t\t\t\t
\t\t\t\t<h4>Votre compte a été activé!</h4>\t\t\t
\t\t\t</li>
\t\t\t<li class=\"notification notification-welcome\">
\t\t\t\t
\t\t\t\t<h4>Bienvenue sur Wazzup!</h4>
\t\t\t\t<p>Vous pouvez maintenant accéder a votre compte</p></li>
\t\t</ul>
\t</div>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "activation/activated.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  123 => 23,  112 => 15,  105 => 10,  95 => 9,  83 => 7,  79 => 6,  75 => 5,  71 => 4,  67 => 2,  57 => 1,  47 => 9,  45 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% block head %}
<meta charset=\"utf-8\">
\t<!-- STYLE CSS -->
\t<link rel=\"stylesheet\" href=\"{{ asset('activation/css/style.css') }}\">
    <link rel=\"shortcut icon\" href=\"{{ asset('signup/img/favicon.ico') }}\">
\t<script src=\"{{ asset('activation/js/script.js') }}\"></script>
\t<script src=\"{{ asset('signup/js/Jquery.js') }}\"></script>
{% endblock %}
{% block body %}
<div id=\"part\" class=\"wrapper\">
\t<div id=\"particles-js\"></div>
     <!-- Latest compiled and minified JavaScript -->
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js\" integrity=\"sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa\" crossorigin=\"anonymous\"></script>
\t\t<script src='https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js'></script>
\t\t<script src=\"{{ asset('signup/js/app.js') }}\"></script>


<div class=\"logo\">
  <div></div>
  <div></div>
  <div></div>
  <svg viewBox=\"0 0 200 300\">
   <img style=\"height: 25vh;\" src=\"{{ asset('signup/img/logo.png') }}\" alt=\"logo_wazzup\">
   </svg>
</div>
<div class=\"sidebar\">

\t\t<ul>
\t\t\t<li class=\"notification notification-activated\">
\t\t\t\t
\t\t\t\t<h4>Votre compte a été activé!</h4>\t\t\t
\t\t\t</li>
\t\t\t<li class=\"notification notification-welcome\">
\t\t\t\t
\t\t\t\t<h4>Bienvenue sur Wazzup!</h4>
\t\t\t\t<p>Vous pouvez maintenant accéder a votre compte</p></li>
\t\t</ul>
\t</div>
    </div>
{% endblock %}", "activation/activated.html.twig", "C:\\Users\\malek\\Desktop\\wazzupwebapp\\templates\\activation\\activated.html.twig");
    }
}
